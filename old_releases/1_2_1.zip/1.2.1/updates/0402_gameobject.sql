-- Sets spawntime of Mythology of the Titans to 50 seconds. http://thottbot.com/quest=1050 "All you gotta do is wait there for at least 50 secs"
UPDATE `gameobject` SET `spawntimesecs`='50' WHERE (`guid`='15008');
