-- Removed duplicate GO 2098 (Cathedral Square) sign as it was duplicate
DELETE FROM `gameobject` WHERE `guid` = 10665;
