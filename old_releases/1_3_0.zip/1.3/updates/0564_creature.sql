-- correct spawnposition of lucifron & adds(ID 12118 & 12119)

UPDATE `creature` SET `position_x` = 1068.86, `position_y` = -1007.76, `position_z` = -185.24 WHERE `guid` = 55605;
UPDATE `creature` SET `position_x` = 1067.9, `position_y` = -1011.6, `position_z` = -185.08 WHERE `guid` = 55606;
UPDATE `creature` SET `position_x` = 1072.56, `position_y` = -1006.57, `position_z` = -185.91 WHERE `guid` = 55607;
