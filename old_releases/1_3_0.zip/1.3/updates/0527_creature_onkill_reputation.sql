UPDATE `creature_onkill_reputation` SET `RewOnKillRepFaction2` = 0, `RewOnKillRepValue1` = 100, `MaxStanding2` = 0, `RewOnKillRepValue2` = 0 WHERE `creature_id` = 15249; -- Qiraji Lasher
UPDATE `creature_onkill_reputation` SET `RewOnKillRepFaction2` = 0, `RewOnKillRepValue1` = 100, `MaxStanding2` = 0, `RewOnKillRepValue2` = 0 WHERE `creature_id` = 15236; -- Vekniss Wasp
UPDATE `creature_onkill_reputation` SET `RewOnKillRepFaction2` = 0, `RewOnKillRepValue1` = 100, `MaxStanding2` = 0, `RewOnKillRepValue2` = 0 WHERE `creature_id` = 15235; -- Vekniss Stinger
