-- Qiraji Mindslayer / Qiraji Slayer

UPDATE `creature_template` SET `Scale` = 1, `MinLevelHealth` = 123840, `MaxLevelHealth` = 123840 WHERE `Entry` = 15246;
UPDATE `creature_template` SET `MinLevelHealth` = 123840, `MaxLevelHealth` = 123840, `SpeedWalk` = 1.6 WHERE `Entry` = 15250;