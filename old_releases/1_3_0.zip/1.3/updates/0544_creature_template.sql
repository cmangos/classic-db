UPDATE creature_template SET MovementType = 2 WHERE entry = 330; -- Princess(ID 330)
