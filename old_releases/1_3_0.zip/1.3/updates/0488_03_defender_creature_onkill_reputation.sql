-- Anubisath Defender
UPDATE `creature_onkill_reputation` SET `RewOnKillRepFaction2` = 0, `RewOnKillRepValue1` = 100, `MaxStanding2` = 0, `RewOnKillRepValue2` = 0 WHERE `creature_id` = 15277;
