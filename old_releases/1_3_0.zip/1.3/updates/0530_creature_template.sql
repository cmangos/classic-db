-- -----------------------

UPDATE `creature_template` SET `SpeedWalk` = 1, `MovementType` = 2 WHERE `Entry` = 10411; -- Eye of Naxxramas
