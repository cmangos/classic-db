-- Made idols lootable without having specific quests. They should always be lootable
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 11 WHERE `entry` = 17533 AND `item` = 20882;
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 19 WHERE `entry` = 17533 AND `item` = 20881;
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 11 WHERE `entry` = 17533 AND `item` = 20879;
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 08 WHERE `entry` = 17533 AND `item` = 20878;
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 16 WHERE `entry` = 17533 AND `item` = 20877;
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 24 WHERE `entry` = 17533 AND `item` = 20876;
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 30 WHERE `entry` = 17533 AND `item` = 20875;
UPDATE `gameobject_loot_template` SET `ChanceOrQuestChance` = 24 WHERE `entry` = 17533 AND `item` = 20874;
