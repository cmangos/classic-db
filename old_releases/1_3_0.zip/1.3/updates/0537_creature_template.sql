UPDATE `creature_template` SET `Scale` = 1.25 WHERE `Entry` = 15461;
UPDATE `creature_template` SET `Scale` = 1.00 WHERE `Entry` = 15462;
