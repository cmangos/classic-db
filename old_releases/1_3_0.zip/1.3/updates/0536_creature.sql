UPDATE `creature` SET `MovementType` = 1, `SpawnDist` = 10 WHERE `id` = 15168;
