-- Vekniss Soldier

DELETE FROM `creature_linking_template` WHERE `entry` = 15229;
INSERT INTO `creature_linking_template`(`entry`, `map`, `master_entry`, `flag`, `search_range`) VALUES (15229, 531, 15510, 1024, 0);
