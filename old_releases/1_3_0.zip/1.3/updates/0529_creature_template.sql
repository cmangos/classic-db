
-- -----------------------

UPDATE `creature_template` SET `SpeedWalk` = 1 WHERE `Entry` = 10405; -- Plague Ghoul
UPDATE `creature_template` SET `SpeedWalk` = 1, `Rank` = 2 WHERE `Entry` = 10393; -- Skul
