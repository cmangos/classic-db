-- Anubisath Defender
UPDATE `creature_template` SET `MinLevelHealth`='471000', `MaxLevelHealth`='471000' WHERE `entry`='15277';
UPDATE `creature` SET `curhealth` = 471000 WHERE `id` = 15277;
