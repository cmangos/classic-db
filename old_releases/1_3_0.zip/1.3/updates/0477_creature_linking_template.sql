-- Obsidian Eradicator, creature 15262
DELETE FROM `creature_linking_template` WHERE `entry` = 15262;
INSERT INTO `creature_linking_template` (`entry`, `map`, `master_entry`, `flag`, `search_range`) VALUES
(15262, 531, 15263, 1024, 0);
