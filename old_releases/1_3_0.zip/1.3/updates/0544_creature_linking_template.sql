-- Linking between Prciness(ID 330) and Porcine Entourage(ID 390) - Aggro On Aggro, Follow
UPDATE `creature_linking_template` SET `flag` = 515 WHERE `entry` = 390 AND `map` = 0;
