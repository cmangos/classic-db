-- Anubisath Defender
DELETE FROM `creature_linking_template` WHERE `entry` = 15277;
INSERT INTO `creature_linking_template` (`entry`, `map`, `master_entry`, `flag`, `search_range`) VALUES
(15277, 531, 15276, 1025, 0);
