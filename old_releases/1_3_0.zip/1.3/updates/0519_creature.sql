-- Fixed position of Qiraji Swarmguard in Ruins of Ahn'Qiraj
UPDATE `creature` SET `position_x` = -8605.820, `position_y` = 1458.300, `position_z` = 32.0320,`MovementType` = 2 WHERE `guid` = 140280;
UPDATE `creature` SET `position_x` = -8634.810, `position_y` = 1443.310, `position_z` = 32.4850,`MovementType` = 2 WHERE `guid` = 140281;
UPDATE `creature` SET `position_x` = -8586.890, `position_y` = 1427.870, `position_z` = 33.0639,`MovementType` = 2 WHERE `guid` = 140282;
UPDATE `creature` SET `position_x` = -8707.966, `position_y` = 1495.304, `position_z` = 32.0320,`MovementType` = 2 WHERE `guid` = 140283;
UPDATE `creature` SET `position_x` = -8677.870, `position_y` = 1540.740, `position_z` = 31.9674,`MovementType` = 2 WHERE `guid` = 140284;
UPDATE `creature` SET `position_x` = -8643.200, `position_y` = 1418.830, `position_z` = 32.9521,`MovementType` = 2 WHERE `guid` = 140285;
