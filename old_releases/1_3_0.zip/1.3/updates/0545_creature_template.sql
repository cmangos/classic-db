UPDATE `creature_template` SET `FactionAlliance` = 7, `FactionHorde` = 7, `MovementType` = 1 WHERE `Entry` = 15333;
