-- The Prophet Skeram
SET @PROPHSK := 88075;

UPDATE `creature` SET `position_x` = -8346.64, `position_y` = 2081.41, `position_z` = 125.65, `spawntimesecs` = 604800 WHERE `id` = 15263;
