-- Lock scarab chests in Temple of Ahn'Qiraj
UPDATE `gameobject_template` SET `flags`='2' WHERE `entry`='180690';