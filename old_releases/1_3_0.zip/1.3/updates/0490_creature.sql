-- Vekniss Soldier

DELETE FROM `creature` WHERE `guid` = 87907;

UPDATE `creature` SET `position_x` = -8160.64, `position_y` = 1669.32, `position_z` = -36.0642, `orientation` = 6.27443, `spawntimesecs` = 600, `curhealth` = 80496, `MovementType` = 2 WHERE `guid` = 87906;
UPDATE `creature` SET `position_x` = -8027.47, `position_y` = 1553.08, `position_z` = -66.5098, `orientation` = 2.26892, `spawntimesecs` = 600, `curhealth` = 80496, `MovementType` = 2 WHERE `guid` = 87905;
UPDATE `creature` SET `position_x` = -7977.78, `position_y` = 1572.38, `position_z` = -61.796, `orientation` = 5.14348, `spawntimesecs` = 600, `curhealth` = 80496, `MovementType` = 2 WHERE `guid` = 87904;
UPDATE `creature` SET `position_x` = -7940.78, `position_y` = 1491.18, `position_z` = -64.0933, `orientation` = 5.48118, `spawntimesecs` = 600, `curhealth` = 80496, `MovementType` = 2 WHERE `guid` = 87903;
UPDATE `creature` SET `position_x` = -7903.95, `position_y` = 1411.55, `position_z` = -66.4528, `orientation` = 4.24687, `spawntimesecs` = 600, `curhealth` = 80496, `MovementType` = 2 WHERE `guid` = 87902;
UPDATE `creature` SET `position_x` = -7955.62, `position_y` = 1322.46, `position_z` = -90.46, `orientation` = 4.38823, `spawntimesecs` = 600, `curhealth` = 80496, `MovementType` = 2 WHERE `guid` = 87901;
