
-- -----------------------

UPDATE `creature_template` SET `MinLevel` = 57, `MovementType` = 2, `SpeedWalk` = 1 WHERE `Entry` = 10414; -- Patchwork Horror

