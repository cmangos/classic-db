-- fix scale of 'Andorgos'
UPDATE `creature_template` SET `scale`='1.75' WHERE `entry`='15502';