-- Anubisath Sentinel
DELETE FROM `creature_linking_template` WHERE `entry` = 15264;
INSERT INTO `creature_linking_template` (`entry`, `map`, `master_entry`, `flag`, `search_range` ) VALUES (15264 ,531 ,15263 ,1024 ,0);
