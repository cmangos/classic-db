-- Updated scale and speed of Qiraji Swarmguard in Ruins of AhnQiraj
UPDATE `creature_template` SET `Scale` = 1.75, `SpeedWalk` = 1.6, `SpeedRun` = 2.4 WHERE `Entry` = 15343;
