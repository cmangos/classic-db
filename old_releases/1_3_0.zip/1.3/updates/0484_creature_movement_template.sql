-- Battleguard Sartura
DELETE FROM `creature_movement_template` WHERE `entry` = 15516;
INSERT INTO `creature_movement_template` (`entry`, `point`, `position_x`, `position_y`, `position_z`, `waittime`, `script_id`, `textid1`, `textid2`, `textid3`, `textid4`, `textid5`, `emote`, `spell`, `wpguid`, `orientation`, `model1`, `model2`) VALUES 
(15516, 1, -8337.2, 1596.45, -31.2387, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0.923705, 0, 0),
(15516, 2, -8263.57, 1746.7, -14.9944, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5.22764, 0, 0),
(15516, 3, -8233.96, 1643.88, -32.8831, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.42121, 0, 0),
(15516, 4, -8338.47, 1698.45, -20.2435, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6.22508, 0, 0),
(15516, 5, -8223.09, 1710.64, -27.4231, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3.04422, 0, 0);
