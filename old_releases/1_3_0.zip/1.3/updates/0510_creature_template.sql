-- Vekniss Drone
UPDATE `creature_template` SET `MinLevelHealth` = 12208, `MaxLevelHealth` = 12208 WHERE `Entry` = 15300;
