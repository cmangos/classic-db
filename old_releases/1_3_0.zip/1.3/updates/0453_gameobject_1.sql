-- remove GO Small Obsidian Chunk (will be spawned if an anubisath dies
DELETE FROM `gameobject` WHERE `guid`='9301';
DELETE FROM `gameobject` WHERE `guid`='9306';
DELETE FROM `gameobject` WHERE `guid`='11495';
DELETE FROM `gameobject` WHERE `guid`='12443';
DELETE FROM `gameobject` WHERE `guid`='14106';
DELETE FROM `gameobject` WHERE `guid`='14124';
DELETE FROM `gameobject` WHERE `guid`='14127';
DELETE FROM `gameobject` WHERE `guid`='14142';