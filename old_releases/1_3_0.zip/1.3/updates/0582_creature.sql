-- Update spawn distance of a few creature in Lordamere Internment Camp
-- This closes #489 
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 17303;
UPDATE `creature` SET `spawndist` = 4, `MovementType` = 1 WHERE `guid` = 17302;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 17306;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 17340;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 17355;
UPDATE `creature` SET `spawndist` = 4, `MovementType` = 1 WHERE `guid` = 17301;
UPDATE `creature` SET `spawndist` = 7, `MovementType` = 1 WHERE `guid` = 17109;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 17293;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 17294;
UPDATE `creature` SET `spawndist` = 6, `MovementType` = 1 WHERE `guid` = 17289;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 16853;
UPDATE `creature` SET `spawndist` = 7, `MovementType` = 1 WHERE `guid` = 16984;
UPDATE `creature` SET `spawndist` = 6, `MovementType` = 1 WHERE `guid` = 16816;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 16873;
UPDATE `creature` SET `spawndist` = 6, `MovementType` = 1 WHERE `guid` = 16859;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 16791;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 18031;
UPDATE `creature` SET `spawndist` = 5, `MovementType` = 1 WHERE `guid` = 16806;
