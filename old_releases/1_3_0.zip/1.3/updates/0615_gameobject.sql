-- Fixed Z-axis of gameobject 2046 (Goldthorn) in Badlands as it was standing into the air
UPDATE `gameobject` SET `position_z` = 249.869 WHERE `guid` = 9188;
