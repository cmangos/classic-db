UPDATE `creature_template` SET `ScriptName` = 'npc_dorius_stonetender' WHERE `Entry` = 8284;
