-- Vekniss Soldier
UPDATE `creature_template` SET  `SpeedWalk` = 4, `MinLevelHealth` = 80496, `MaxLevelHealth` = 80496 WHERE `Entry` = 15229;
