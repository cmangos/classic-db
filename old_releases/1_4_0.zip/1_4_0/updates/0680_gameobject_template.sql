
-- -------------------------

UPDATE `gameobject_template` SET `size`='1.4' WHERE `entry`='180691';
