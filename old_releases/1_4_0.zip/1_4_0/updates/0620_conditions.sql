
-- --------------------

DELETE FROM `conditions` WHERE `condition_entry`='324';
DELETE FROM `conditions` WHERE `condition_entry`='327';
DELETE FROM `conditions` WHERE `condition_entry`='328';
