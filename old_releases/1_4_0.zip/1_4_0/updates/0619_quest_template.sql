
-- --------------------

UPDATE `quest_template` SET `NextQuestInChain`='7383' WHERE `entry`='933';                                  -- Crown of the Earth
UPDATE `quest_template` SET `PrevQuestId`='7383' WHERE `entry`='935';                                       -- Crown of the Earth
UPDATE `quest_template` SET `RequiredRaces`='255', `MinLevel`='40', `QuestLevel`='47' WHERE `entry`='8551'; -- The Captain's Chest
UPDATE `quest_template` SET `rewmoneymaxlevel`='3960' WHERE `entry`='8920';                                 -- An Earnest Proposition
UPDATE `quest_template` SET `rewmoneymaxlevel`='3960' WHERE `entry`='8957';                                 -- Anthion's Parting Words
