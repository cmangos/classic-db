
-- -----------------------

UPDATE `creature_template` SET `Scale`='1' WHERE `Entry`='15521';
