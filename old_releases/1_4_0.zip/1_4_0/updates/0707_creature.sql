-- Removed creatures spawned in TBC map
-- Thanks Castro for pointing
DELETE FROM `creature` WHERE `map`= 269; -- Caverns of Time: Opening the Dark Portal
