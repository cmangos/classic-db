
-- Firelord, Lava Spawn, Flameguard, Firewalker, Son of Flame, Baron Geddon, Ancient Core Hound

-- -----------------------

UPDATE `creature_template` SET `DamageSchool`='2' WHERE `Entry` IN ('11666', '11667', '11668', '11673', '12056', '12143', '12265');
