
-- -----------------------

UPDATE `creature_template` SET `DamageSchool`='2', `ResistanceHoly`='0', `ResistanceFire`='0', `ResistanceNature`='0', `ResistanceFrost`='0', `ResistanceShadow`='0', `ResistanceArcane`='0', `MovementType`='2' WHERE `Entry`='9026';
UPDATE `creature_template` SET `SpeedWalk`='1', `UnitClass`='1', `Rank`='2', `Armor`='2999' WHERE `Entry`='8924';
