
UPDATE `quest_template` SET `RewMoneyMaxLevel`='1710' WHERE `entry`='1287';
UPDATE `quest_template` SET `RewMoneyMaxLevel`='7140' WHERE `entry`='8869';
