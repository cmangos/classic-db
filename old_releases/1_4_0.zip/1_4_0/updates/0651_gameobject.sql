-- Removed wrong objective gameobject 186419 (Wrecked Row Boat) in Feralas. There is GO here.
-- Source: http://www.wowhead.com/object=164909#screenshots:id=13993
DELETE FROM `gameobject` WHERE `id` = 186419;
