
-- ------------------------------------

INSERT INTO `creature_linking_template` (`entry`, `map`, `master_entry`, `flag`, `search_range`) VALUES
('12101', '409', '12057', '1024', '0');
