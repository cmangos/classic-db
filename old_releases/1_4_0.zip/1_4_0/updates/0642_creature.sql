
-- --------------

UPDATE `creature` SET `curhealth`='80925' WHERE `id`='11667'; -- Flame Guard
UPDATE `creature` SET `curhealth`='80925' WHERE `id`='12076'; -- Lava Elemental
UPDATE `creature` SET `curhealth`='83275' WHERE `id`='12100'; -- Lava Reaver

UPDATE `creature` SET `spawntimesecs`='9000' WHERE `id`='11665'; -- Lava Annihilator
UPDATE `creature` SET `spawntimesecs`='9000' WHERE `id`='11668'; -- Firelord
UPDATE `creature` SET `spawntimesecs`='1680' WHERE `id`='12101'; -- Lava Surger
