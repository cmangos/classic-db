
UPDATE `quest_template` SET `MinLevel`='42' WHERE `entry`='81';
UPDATE `quest_template` SET `MinLevel`='54' WHERE `entry`='1018';
UPDATE `quest_template` SET `MinLevel`='25' WHERE `entry`='1434';
UPDATE `quest_template` SET `MinLevel`='25' WHERE `entry`='1435';
UPDATE `quest_template` SET `MinLevel`='28' WHERE `entry`='2950';
UPDATE `quest_template` SET `MinLevel`='9' WHERE `entry`='5729';
UPDATE `quest_template` SET `MinLevel`='9' WHERE `entry`='5730';
UPDATE `quest_template` SET `MinLevel`='52' WHERE `entry`='7341';
UPDATE `quest_template` SET `MinLevel`='6' WHERE `entry`='7926';
