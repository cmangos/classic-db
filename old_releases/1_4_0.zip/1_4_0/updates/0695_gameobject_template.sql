
-- -------------------------

UPDATE `gameobject_template` SET `flags`='32' WHERE `entry`='180634';
UPDATE `gameobject_template` SET `flags`='32' WHERE `entry`='180635';
UPDATE `gameobject_template` SET `flags`='32' WHERE `entry`='180636';
UPDATE `gameobject_template` SET `faction`='94', `data15`='1' WHERE `entry`='180690';
UPDATE `gameobject_template` SET `faction`='114', `data3`='3000' WHERE `entry`='180795';
UPDATE `gameobject_template` SET `faction`='94', `data18`='60', `data19`='1' WHERE `entry`='181069';
