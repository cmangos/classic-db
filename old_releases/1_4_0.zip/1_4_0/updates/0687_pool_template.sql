
-- ------------------------

DELETE FROM `pool_template` WHERE `entry`='25467';
INSERT INTO `pool_template` (`entry`, `max_limit`, `description`) VALUES
('25467', '1', 'BRD - Molten War Golem / Panzor the Invincible');
