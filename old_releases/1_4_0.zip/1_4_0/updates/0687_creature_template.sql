
-- -----------------------

UPDATE `creature_template` SET `SpeedWalk`='1', `UnitClass`='1', `Rank`='2', `Armor`='4955', `ResistanceFire`='153', `ResistanceNature`='153', `ResistanceFrost`='153', `ResistanceShadow`='153', `ResistanceArcane`='153', `MovementType`='2' WHERE `Entry`='8923';
UPDATE `creature_template` SET `ResistanceFrost`='-140' WHERE `Entry`='8908';
