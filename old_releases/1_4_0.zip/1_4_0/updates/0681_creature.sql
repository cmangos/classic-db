
-- --------------

UPDATE `creature` SET `position_x`='-9270.393', `position_y`='1243.896', `position_z`='-63.76731', `orientation`='2.722714' WHERE `guid`='139974';
UPDATE `creature` SET `position_x`='-9300.067', `position_y`='1305.085', `position_z`='-63.69709', `orientation`='4.188790' WHERE `guid`='139975';
UPDATE `creature` SET `position_x`='-9300.189', `position_y`='1266.665', `position_z`='-63.74272', `orientation`='0.261799' WHERE `guid`='139976';
UPDATE `creature` SET `position_x`='-9243.427', `position_y`='1280.498', `position_z`='-63.59377', `orientation`='3.822271' WHERE `guid`='139977';
UPDATE `creature` SET `position_x`='-9263.014', `position_y`='1295.236', `position_z`='-63.80813', `orientation`='1.797689' WHERE `guid`='139978';
UPDATE `creature` SET `position_x`='-9234.326', `position_y`='1243.826', `position_z`='-63.52806', `orientation`='3.490659' WHERE `guid`='139979';
