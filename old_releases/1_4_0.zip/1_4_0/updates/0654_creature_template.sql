
-- --- | TRASH |---
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11658';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11659';

UPDATE `creature_template` SET `MechanicImmuneMask`='116097015' WHERE `entry`='11668';
UPDATE `creature_template` SET `MechanicImmuneMask`='116097015' WHERE `entry`='12265';
UPDATE `creature_template` SET `MechanicImmuneMask`='116097015' WHERE `entry`='11667';
UPDATE `creature_template` SET `MechanicImmuneMask`='116097015' WHERE `entry`='11666';

UPDATE `creature_template` SET `MechanicImmuneMask`='115965943' WHERE `entry`='11665';
UPDATE `creature_template` SET `MechanicImmuneMask`='115965943' WHERE `entry`='12101';
UPDATE `creature_template` SET `MechanicImmuneMask`='115965943' WHERE `entry`='12076';
UPDATE `creature_template` SET `MechanicImmuneMask`='115965943' WHERE `entry`='12100';

UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11673';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11671';

UPDATE `creature_template` SET `MechanicImmuneMask`='82540279' WHERE `entry`='11669';

-- --- | BOSS GUARDS |---
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='12119';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11661';
UPDATE `creature_template` SET `MechanicImmuneMask`='115965943' WHERE `entry`='12099';
UPDATE `creature_template` SET `MechanicImmuneMask`='82526199' WHERE `entry`='11662';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11664';
UPDATE `creature_template` SET `MechanicImmuneMask`='82524151' WHERE `entry`='11663';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11672';
UPDATE `creature_template` SET `MechanicImmuneMask`='74007075' WHERE `entry`='12143';

-- --- | BOSS |---
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='12118';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11982';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='12259';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='12057';
UPDATE `creature_template` SET `MechanicImmuneMask`='116097015' WHERE `entry`='12056';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='12264';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='12098';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='11988';
UPDATE `creature_template` SET `MechanicImmuneMask`='116080631' WHERE `entry`='12018';
UPDATE `creature_template` SET `MechanicImmuneMask`='116097015' WHERE `entry`='11502';
