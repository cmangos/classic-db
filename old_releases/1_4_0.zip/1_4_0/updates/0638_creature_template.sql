
-- small fix of unitflags and ranks in MC

-- -----------------------

UPDATE `creature_template` SET `UnitFlags`='1' WHERE `Entry`='12265';     -- Lava Spawn
UPDATE `creature_template` SET `Rank`='1' WHERE `Entry`='12100';          -- Lava Reaver
UPDATE `creature_template` SET `Rank`='1' WHERE `Entry`='11667';          -- Flameguard
UPDATE `creature_template` SET `Rank`='1' WHERE `Entry`='12076';          -- Lava Elemental
