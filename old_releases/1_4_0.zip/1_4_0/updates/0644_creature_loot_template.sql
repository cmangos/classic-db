
-- Canal Frenzy, Qiraji Warrior, Swarmguard Needler, Anubisath Swarmguard, Anubisath Warrior, Flame Imp, Core Hound, Lava Spawn, Firesworn, Core Rager, Son of Flame

DELETE FROM `creature_loot_template` WHERE `entry` IN ('15505', '15387', '15344', '15538', '15537', '11669', '11671', '12265', '12099', '11672', '12143');
