
UPDATE `gameobject` SET `spawntimesecs`='0' WHERE `guid`='43133';
