
-- ---------------------------------

DELETE FROM `creature_questrelation` WHERE `quest`='934'; -- Crown of the Earth
DELETE FROM `creature_questrelation` WHERE `quest`='614'; -- The Captain's Chest
