
-- -----------------------

UPDATE `creature_template` SET `UnitClass`='2' WHERE `Entry` IN ('417', '1860', '1863'); -- Felhunter, Voidwalker, Succubus
UPDATE `creature_template` SET `UnitClass`='8' WHERE `Entry`='416'; -- Imp
