
SET @RESPAWN := '7200';

SET @SOLIDCHEST1 := '153451'; -- Solid Chest 1
SET @SOLIDCHEST2 := '153453'; -- Solid Chest 2
SET @SOLIDCHEST3 := '153454'; -- Solid Chest 3

SET @LARGESOLIDCHEST1 := '153462'; -- Large Solid Chest 1
SET @LARGESOLIDCHEST2 := '153463'; -- Large Solid Chest 2
SET @LARGESOLIDCHEST3 := '153464'; -- Large Solid Chest 3

-- ----------------

UPDATE `gameobject` SET `spawntimesecs`='7200' WHERE `id` IN (@SOLIDCHEST1, @SOLIDCHEST2, @SOLIDCHEST3, @LARGESOLIDCHEST1, @LARGESOLIDCHEST2, @LARGESOLIDCHEST3) AND NOT `spawntimesecs`=@RESPAWN;
