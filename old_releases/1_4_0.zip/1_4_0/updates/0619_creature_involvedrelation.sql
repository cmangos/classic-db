
-- ------------------------------------

DELETE FROM `creature_involvedrelation` WHERE `quest`='934'; -- Crown of the Earth
DELETE FROM `creature_involvedrelation` WHERE `quest`='614'; -- The Captain's Chest
