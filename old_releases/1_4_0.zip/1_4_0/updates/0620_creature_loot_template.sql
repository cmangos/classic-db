
-- ----------------------------

UPDATE `creature_loot_template` SET `condition_id`='0' WHERE `entry`='6910' and`item`='7741';

