
-- ---------------------

DELETE FROM `gameobject` WHERE `guid`='232227';
