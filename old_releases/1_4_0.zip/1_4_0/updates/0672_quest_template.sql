
UPDATE `quest_template` SET `MinLevel`='44' WHERE `entry`='3504';
UPDATE `quest_template` SET `MinLevel`='44' WHERE `entry`='3505';
UPDATE `quest_template` SET `MinLevel`='44', `RewMoneyMaxLevel`='2610' WHERE `entry`='3506';
UPDATE `quest_template` SET `MinLevel`='44' WHERE `entry`='3507';
