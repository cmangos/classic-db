
-- ----------------

UPDATE `gameobject` SET `position_x`='1265.855', `position_y`='-285.0983', `position_z`='-78.21929', `orientation`='3.909541', `rotation2`='-0.9271832', `rotation3`='0.3746083' WHERE `id`='169243';
