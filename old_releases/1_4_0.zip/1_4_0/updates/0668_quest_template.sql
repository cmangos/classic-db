
-- --------------------

UPDATE `quest_template` SET `SpecialFlags`='0' WHERE `entry`='7830';
