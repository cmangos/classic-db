
-- -----------------------

UPDATE `creature_template` SET `Scale`='2' WHERE `Entry`='15514';
