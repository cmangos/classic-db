
-- Canal Frenzy, Qiraji Warrior, Swarmguard Needler, Anubisath Swarmguard, Anubisath Warrior, Flame Imp, Core Hound, Lava Spawn, Firesworn, Core Rager, Son of Flame

UPDATE `creature_template` SET `LootId`='0', `SkinningLootId`='0', `MinLootGold`='0', `MaxLootGold`='0' WHERE `entry` IN ('15505', '15387', '15344', '15538', '15537', '11669', '11671', '12265', '12099', '11672', '12143');
