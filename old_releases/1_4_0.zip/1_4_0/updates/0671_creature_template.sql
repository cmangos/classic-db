
UPDATE `creature_template` SET `FactionAlliance`='26', `FactionHorde`='26' WHERE `Entry`='80';
