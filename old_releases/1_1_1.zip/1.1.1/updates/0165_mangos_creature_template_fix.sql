-- Adjust scale of creature 7750 (Corporal Thund Splithoof) to match other taurens size
UPDATE `creature_template` SET `scale` = 1.35 WHERE `entry` = 7750;
