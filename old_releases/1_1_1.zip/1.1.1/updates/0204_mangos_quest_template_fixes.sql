-- correct minLevel for some quests in Mulgore
-- Source: http://www.wowwiki.com/Quest:The_Hunt_Continues?oldid=305244
UPDATE `quest_template` SET `MinLevel` = 1 WHERE `entry` = 750;
-- Source: http://www.wowwiki.com/Quest:The_Ravaged_Caravan_(Horde)_(1)?direction=next&oldid=813397
UPDATE `quest_template` SET `MinLevel` = 5 WHERE `entry` = 751;
-- Source: http://www.wowwiki.com/Quest:Winterhoof_Cleansing?oldid=144845
UPDATE `quest_template` SET `MinLevel` = 4 WHERE `entry` = 754;
-- Source: http://www.wowwiki.com/Quest:Rites_of_the_Earthmother?oldid=138106
UPDATE `quest_template` SET `MinLevel` = 1 WHERE `entry` = 755;
-- Source: http://www.wowwiki.com/Quest:Thunderhorn_Totem?oldid=144855
UPDATE `quest_template` SET `MinLevel` = 5 WHERE `entry` = 756;
-- Source: http://www.wowwiki.com/Quest:Thunderhorn_Cleansing?oldid=144870
UPDATE `quest_template` SET `MinLevel` = 5 WHERE `entry` = 758;
-- Source: http://www.wowwiki.com/Quest:Wildmane_Totem?oldid=145421
UPDATE `quest_template` SET `MinLevel` = 7 WHERE `entry` = 759;
-- Source: http://www.wowwiki.com/Quest:Wildmane_Cleansing?oldid=145434
UPDATE `quest_template` SET `MinLevel` = 7 WHERE `entry` = 760;
-- Source: http://www.wowwiki.com/Quest:Rites_of_the_Earthmother?oldid=138106
UPDATE `quest_template` SET `MinLevel` = 1 WHERE `entry` = 763;
-- Source: http://www.wowwiki.com/Quest:Supervisor_Fizsprocket?direction=next&oldid=879945
UPDATE `quest_template` SET `MinLevel` = 5 WHERE `entry` = 765;
-- Source: http://www.wowwiki.com/Quest:Mazzranache?oldid=825433
UPDATE `quest_template` SET `MinLevel` = 5 WHERE `entry` = 766;
-- Source: http://www.wowwiki.com/Quest:Rite_of_Vision?oldid=138545
UPDATE `quest_template` SET `MinLevel` = 3 WHERE `entry` = 772;
-- Source: http://www.wowwiki.com/Quest:Rite_of_Wisdom?oldid=138241
UPDATE `quest_template` SET `MinLevel` = 4 WHERE `entry` = 773;
-- Source: http://www.wowwiki.com/Quest:Journey_into_Thunder_Bluff?oldid=138266
UPDATE `quest_template` SET `MinLevel` = 4 WHERE `entry` = 775;
-- Source: http://www.wowwiki.com/Quest:Rites_of_the_Earthmother_(3)?oldid=138270
UPDATE `quest_template` SET `MinLevel` = 7 WHERE `entry` = 776;
-- Source: http://www.wowwiki.com/Quest:Attack_on_Camp_Narache?oldid=138865
UPDATE `quest_template` SET `MinLevel` = 3 WHERE `entry` = 781;