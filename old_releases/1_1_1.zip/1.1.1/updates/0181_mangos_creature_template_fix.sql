-- Update InhabitType of creature 7046 (Searscale Drake): let it hover!
UPDATE `creature_template` SET `InhabitType` = 3 WHERE `entry` = 7046;
