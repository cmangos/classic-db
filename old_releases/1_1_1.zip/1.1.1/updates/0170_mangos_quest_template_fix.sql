-- Changed min level for quest 355 (Speak with Sevren)
-- Source: http://www.wowwiki.com/Quest:Speak_with_Sevren?oldid=818961
UPDATE `quest_template` SET `MinLevel` = 7 WHERE `entry` = 355;
