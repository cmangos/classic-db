-- Adds addon to make creature 10740 (Awbee) lying on the ground
-- Thanks Stan84 for pointing and fixing
-- Source: http://www.wowwiki.com/Awbee
INSERT INTO `creature_template_addon` VALUES (10740, 0, 7, 0, 0, 0, 0, '');
